# lifesteal_sword
/give @s minecraft:netherite_sword[minecraft:item_model="lifesteal:lifesteal_sword"] 1

# lifesteal_axe
/give @s minecraft:netherite_axe[minecraft:item_model="lifesteal:lifesteal_axe"] 1

# lifesteal_pickaxe
/give @s minecraft:netherite_pickaxe[minecraft:item_model="lifesteal:lifesteal_pickaxe"] 1

# lifesteal_shovel
/give @s minecraft:netherite_shovel[minecraft:item_model="lifesteal:lifesteal_shovel"] 1

# lifesteal_hoe
/give @s minecraft:netherite_hoe[minecraft:item_model="lifesteal:lifesteal_hoe"] 1

# lifesteal_mace
/give @s minecraft:mace[minecraft:item_model="lifesteal:lifesteal_mace"] 1

# lifesteal_trident
/give @s minecraft:trident[minecraft:item_model="lifesteal:lifesteal_trident"] 1

# lifesteal_spear
/give @s minecraft:netherite_spear[minecraft:item_model="lifesteal:lifesteal_spear"] 1

# lifesteal_shield
/give @s minecraft:shield[minecraft:item_model="lifesteal:lifesteal_shield"] 1

# lifesteal_bow
/give @s minecraft:bow[minecraft:item_model="lifesteal:lifesteal_bow"] 1

# lifesteal_helmet
/give @s minecraft:netherite_helmet[minecraft:item_model="lifesteal:lifesteal_helmet"] 1

# lifesteal_chestplate
/give @s minecraft:netherite_chestplate[minecraft:item_model="lifesteal:lifesteal_chestplate"] 1

# lifesteal_leggings
/give @s minecraft:netherite_leggings[minecraft:item_model="lifesteal:lifesteal_leggings"] 1

# lifesteal_boots
/give @s minecraft:netherite_boots[minecraft:item_model="lifesteal:lifesteal_boots"] 1
