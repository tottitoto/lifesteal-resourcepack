LIFESTEAL SET — MINECRAFT JAVA 26.2
===================================

INSTALACJA
1. Włóż cały plik ZIP do folderu .minecraft/resourcepacks
2. Włącz paczkę w Opcje > Paczki zasobów.
3. Na serwerze gracz także musi mieć włączoną tę paczkę albo serwer musi ją wysyłać.

PRZEDMIOTY SPECJALNE
Zwykłe przedmioty pozostają bez zmian. Tekstura Lifesteal pojawia się tylko
na przedmiocie z komponentem minecraft:item_model.

Przykład:
/give @s minecraft:netherite_sword[minecraft:item_model="lifesteal:lifesteal_sword"] 1

Wszystkie komendy:
commands/give_all.mcfunction

CO DZIAŁA W TEJ WERSJI
- miecz, siekiera, kilof, łopata, motyka i buzdygan
- łuk wraz z trzema etapami naciągania
- ikony zbroi
- tarcza jako własny model przedmiotu
- trójząb jako własny model przedmiotu
- tymczasowa włócznia wykorzystująca dostarczoną ikonę trójzębu

WAŻNE O ZBROI NOSZONEJ
Pliki Netherite_Helmet_JE1, Chestplate, Leggings i Boots są renderami
gotowych brył 3D, a nie arkuszami UV zbroi. Minecraft nie może nałożyć
takiego renderu na gracza jako tekstury noszonej zbroi.

Dlatego:
- ikony zbroi Lifesteal działają,
- po założeniu zbroja na razie pozostaje zwykłą zbroją neterytową.

Rendery zachowano w folderze source_renders_armor. Aby wykonać wersję noszoną,
potrzebne są właściwe arkusze UV:
- humanoid/lifesteal.png
- humanoid_leggings/lifesteal.png

WAŻNE O MODELACH 3D
W ZIP-ie nie było plików .json ani .bbmodel, tylko obrazy PNG/WEBP/JPEG.
Paczka używa więc płaskich modeli generowanych z tekstur. Prawdziwy model 3D
trójzębu lub tarczy wymaga przesłania eksportu JSON albo projektu .bbmodel.

WŁÓCZNIA
Nie było osobnej tekstury włóczni. Plik:
assets/lifesteal/textures/item/lifesteal_spear_TEMP_REPLACE.png
jest tymczasowy. Można go podmienić na własną teksturę bez zmiany JSON-ów.
